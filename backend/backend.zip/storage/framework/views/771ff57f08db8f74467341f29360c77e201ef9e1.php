
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\backend\resources\views/admin/home.blade.php ENDPATH**/ ?>