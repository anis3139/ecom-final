
<?php if(Session::has('success')): ?>
<script>
    toastr.success("<?php echo e(Session::get('success')); ?>")
    
  </script>
<?php endif; ?>
<?php if(Session::has('error')): ?>
<script>
    toastr.error("<?php echo e(Session::get('error')); ?>")
    
  </script>
<?php endif; ?>
<?php if(Session::has('warning')): ?>
<script>
    toastr.warning("<?php echo e(Session::get('warning')); ?>")
    
  </script>
<?php endif; ?>
<?php if(Session::has('info')): ?>
<script>
    toastr.info("<?php echo e(Session::get('info')); ?>")
    
  </script>
<?php endif; ?>

<?php /**PATH C:\Users\Abedin\Documents\GitHub\ecom-final\frontend\resources\views/client/components/toastr.blade.php ENDPATH**/ ?>