<?php echo e($slot); ?>

<?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>