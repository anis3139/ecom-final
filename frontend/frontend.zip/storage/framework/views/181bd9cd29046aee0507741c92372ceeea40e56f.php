
<?php $__env->startSection('css'); ?>

<style>
.profile{
    margin: 20px 0px!important;
}
.profile-link{
    position: fixed;
    top: 200px;
    right: 5px;
    background-color:#FF6666;
    color:#fff;
    padding: 10px;
    border-radius: 20px;
    display: inline-block;
    animation-name: profile-link;
    animation-duration: 2s;
    animation-iteration-count: infinite;
    }
    @keyframes  profile-link {
  0%   {background-color: red;}
  50%  {background-color: #FF6666;}
  100% {background-color: rgb(228, 122, 23);}
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-10 offset-md-1">
            <a class="profile-link" href="<?php echo e(route('client.profile')); ?>">Go Your Profile</a>
            <h2 class=" profile  text-center">Order id: <?php echo e($orders->id); ?></h2>
            <?php echo $__env->make('client.components.massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>

                        <th>Title</th>
                        <th>Details</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_string($value)): ?>


                    <?php if($column=='user_id'): ?> <?php continue; ?>
                    <?php elseif($column=='id'): ?> <?php continue; ?>
                    <?php elseif($column=='order_product_id'): ?> <?php continue; ?>
                    <?php elseif($column=='product_owner_id'): ?> <?php continue; ?>
                    <?php endif; ?>
                        <tr>
                            <td><?php echo e(ucwords(str_replace('_',' ', $column))); ?></td>
                            <td><?php echo e($value); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-10 offset-md-1">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>

                        <th class="text-center">Product Title</th>
                        <th class="text-center">Quantity</th>
                        <th class="text-center">Color</th>
                        <th class="text-center">Maserment</th>
                        <th class="text-center">Total Price</th>

                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $orders->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td class="text-center"><?php echo e($product->product->product_title); ?></td>
                            <td class="text-center"><?php echo e($product->quantity); ?></td>

                            <td style="display:flex; justify-content:center; align-items: center;">
                                <?php if($product->color): ?>

                               <div style=" width:20px; height:20px; border:1px solid #000; border-radius:50%; background-color: <?php echo e($product->color); ?>;"></div>
                                <?php else: ?>
                                <?php echo e("N/A"); ?>

                            <?php endif; ?>

                            </td>
                            <td class="text-center"><?php if($product->maserment): ?>
                               <?php echo e($product->maserment); ?>

                                <?php else: ?>
                                <?php echo e("N/A"); ?>

                            <?php endif; ?></td>
                            <td class="text-center">&euro;&nbsp;<?php echo e(number_format($product->price, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asulsisc/public_html/resources/views/client/pages/orderDetails.blade.php ENDPATH**/ ?>