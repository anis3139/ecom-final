<?php
$others=App\Models\OthersModel::first();
$socialData=App\Models\SocialModel::first();

?>


<section id="aa-banner">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="aa-banner-area">
            <a href="#"><img src="<?php if($others): ?>
                        <?php echo e($others->promo_image_one); ?>

                        <?php endif; ?>" alt="fashion banner img"></a>
          </div>
          </div>
        </div>
      </div>
    </div>
  </section><?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/partials/promoOne.blade.php ENDPATH**/ ?>