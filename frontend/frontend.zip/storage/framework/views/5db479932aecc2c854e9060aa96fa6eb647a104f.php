<?php
$others=App\Models\OthersModel::first();
$socialData=App\Models\SocialModel::first();

?>

<!-- footer -->
<footer id="aa-footer">
    <!-- footer bottom -->
    <div class="aa-footer-top">
     <div class="container">
        <div class="row">
        <div class="col-md-12">
          <div class="aa-footer-top-area">
            <div class="row">
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <h3>Main Menu</h3>
                  <ul class="aa-footer-nav">
                    <li><a href="<?php echo e(route('client.home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('client.shop')); ?>">Shop</a></li>
                    <li><a href="<?php echo e(route('client.shop')); ?>">About us</a></li>
                    <li><a href="<?php echo e(route('client.contact')); ?>">Contact</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <div class="aa-footer-widget">
                    <h3>Knowledge Base</h3>
                    <ul class="aa-footer-nav">
                      <li><a href="#">Delivery</a></li>
                      <li><a href="#">Returns</a></li>
                      <li><a href="#">Services</a></li>
                      <li><a href="#">Privecy Policy</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <div class="aa-footer-widget">
                    <h3>Your Links</h3>
                    <ul class="aa-footer-nav">
                      <?php if(auth()->guard()->check()): ?>
                      <li><a href="<?php echo e(route('client.profile')); ?>">My Account</a></li>
                      <li><a href="<?php echo e(route('client.logout')); ?>">Log Out</a></li>
                      <?php endif; ?>
                      <?php if(auth()->guard()->guest()): ?>
                      <li><a href="" data-toggle="modal" data-target="#login-modal">Login</a></li>
                      <li><a href="<?php echo e(route('client.registration')); ?>" >Registration</a></li>
                      <?php endif; ?>
                      <li><a href="<?php echo e(route('client.checkout')); ?>">Checkout</a></li>
                    <li><a href="<?php echo e(route('client.showCart')); ?>">My Cart</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <div class="aa-footer-widget">
                    <h3>Contact Us</h3>
                    <address>
                      <p> <?php if($others): ?>
                        <?php echo nl2br(e($others->address)); ?>

                        <?php endif; ?></p>
                      <p><span class="fa fa-phone"></span><a style="color:#888888" href="tel: <?php if($others): ?>
                        <?php echo e($others->phone); ?>

                        <?php endif; ?>"> <?php if($others): ?>
                        <?php echo e($others->phone); ?>

                        <?php endif; ?></a></p>
                      <p><span class="fa fa-envelope"></span><a style="color:#888888" href="mailto: <?php if($others): ?>
                        <?php echo e($others->email); ?>

                        <?php endif; ?>"> <?php if($others): ?>
                        <?php echo e($others->email); ?>

                        <?php endif; ?></a></p>
                    </address>
                    <div class="aa-footer-social">
                      <a href="<?php if($socialData): ?>
                                   <?php echo e($socialData->facebook); ?>

                                   <?php endif; ?>"><span class="fa fa-facebook"></span></a>
                      <a href="<?php if($socialData): ?>
                                   <?php echo e($socialData->twitter); ?>

                                   <?php endif; ?>"><span class="fa fa-twitter"></span></a>
                      <a href="<?php if($socialData): ?>
                                   <?php echo e($socialData->instragram); ?>

                                   <?php endif; ?>"><span class="fa fa-instagram"></span></a>
                      <a href="<?php if($socialData): ?>
                                   <?php echo e($socialData->youtube); ?>

                                   <?php endif; ?>"><span class="fa fa-youtube"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
     </div>
    </div>
    <!-- footer-bottom -->
    <div class="aa-footer-bottom">
      <div class="container">
        <div class="row">
        <div class="col-md-12">
          <div class="aa-footer-bottom-area">
            <p>Developed by <a href="https://www.facebook.com/anis3139">Anis Arronno</a></p>
            <div class="aa-footer-payment">
              <span class="fa fa-cc-mastercard"></span>
              <span class="fa fa-cc-visa"></span>
              <span class="fa fa-paypal"></span>
              <span class="fa fa-cc-discover"></span>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  </footer>
  <!-- / footer -->

<?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/components/footer.blade.php ENDPATH**/ ?>