<?php
$others=App\Models\OthersModel::first();

?>
<?php if($others): ?>
<section id="aa-catg-head-banner">
    <img src="<?php echo e($others->hero_banner); ?>" alt="image" id="bannerImage">
    <div class="aa-catg-head-banner-area">
        <div class="container">
            <div class="aa-catg-head-banner-content" >
                <h2><?php echo e(config('app.name', 'Anis Arronno')); ?></h2>
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('client.home')); ?>">Home</a></li>
                    <li class="active">Shop</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH C:\Users\Abedin\Documents\GitHub\ecom-final\frontend\resources\views/client/components/hero.blade.php ENDPATH**/ ?>