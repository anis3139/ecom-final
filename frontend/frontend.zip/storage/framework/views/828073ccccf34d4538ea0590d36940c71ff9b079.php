
 <?php
 $HomeAboutSectionData= json_decode(App\Models\HomeAboutSecTionModel::orderBy('id', 'desc')->get()->first());
?>
<section id="aa-testimonial" style="background-image: url('<?php if($HomeAboutSectionData): ?><?php echo e($HomeAboutSectionData->exp_image); ?><?php endif; ?>')">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-testimonial-area">
            <ul class="aa-testimonial-slider">
              <?php
                    $HomeTestimonialDatas= json_decode(App\Models\TestimonialModel::orderBy('id', 'desc')->limit(3)->get());
              ?>
              <!-- single slide -->
              <?php $__currentLoopData = $HomeTestimonialDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HomeTestimonialData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
          
              <li>
                <div class="aa-testimonial-single">
                <img class="aa-testimonial-img" src="<?php if($HomeAboutSectionData): ?><?php echo e($HomeTestimonialData->image); ?><?php endif; ?>" alt="testimonial img">
                  <span class="fa fa-quote-left aa-testimonial-quote"></span>
                  <p><?php if($HomeAboutSectionData): ?><?php echo nl2br(e( $HomeTestimonialData->description)); ?><?php endif; ?></p>
                  <div class="aa-testimonial-info">
                    <p><?php if($HomeAboutSectionData): ?><?php echo e($HomeTestimonialData->name); ?><?php endif; ?></p>
                    <span><?php if($HomeAboutSectionData): ?><?php echo e($HomeTestimonialData->date); ?><?php endif; ?></span>
                    
                  </div>
                </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / Testimonial -->
<?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/components/testimonial.blade.php ENDPATH**/ ?>