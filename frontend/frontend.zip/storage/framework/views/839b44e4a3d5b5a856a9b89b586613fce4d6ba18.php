<?php
$others=App\Models\OthersModel::first();

?>
<?php if($others): ?>
<section id="aa-catg-head-banner">
    <img src="<?php echo e($others->hero_banner); ?>" alt="image"  width="100%" height="500px">
    <div class="aa-catg-head-banner-area">
        <div class="container">
            <div class="aa-catg-head-banner-content">
                <h2>Asulsis</h2>
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('client.home')); ?>">Home</a></li>
                    <li class="active">Shop</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php endif; ?><?php /**PATH /home/asulsisc/public_html/resources/views/client/components/hero.blade.php ENDPATH**/ ?>