<!-- Start Promo section -->
  <section id="aa-promo">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-promo-area">
            <div class="row">
              <!-- promo left -->
              <?php $__currentLoopData = $promo_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($loop->first): ?>
              <div class="col-md-5 no-padding">                
                <div class="aa-promo-left">
                  <div class="aa-promo-banner">                    
                    <img src="<?php echo e($category->icon); ?>" alt="img">                    
                    <div class="aa-prom-content">
                      <h4><a href="<?php echo e(route('client.category', $category->slug)); ?>"><?php echo e($category->name); ?></a></h4>                      
                    </div>
                  </div>
                </div>
              </div>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!-- promo right -->
              <div class="col-md-7 no-padding">
                <div class="aa-promo-right">
                  <?php $__currentLoopData = $promo_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($key > 0): ?>
                  <div class="aa-single-promo-right">
                    <div class="aa-promo-banner">                      
                      <img src="<?php echo e($category->icon); ?>" alt="img">                  
                      <div class="aa-prom-content">
                        <h4><a href="<?php echo e(route('client.category', $category->slug)); ?>"><?php echo e($category->name); ?></a></h4>                        
                      </div>
                    </div>
                  </div>
                 
                  <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><?php /**PATH /home/asulsisc/public_html/resources/views/client/partials/promo.blade.php ENDPATH**/ ?>