
<?php $__env->startSection('css'); ?>

<style>
    .aa-login-form input[type="email"], .aa-login-form input[type="number"]{
    border: 1px solid #ccc;
    font-size: 16px;
    height: 40px;
    margin-bottom: 15px;
    padding: 10px;
    width: 100%;
    }
}
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

 <!-- catg header banner section -->
 <?php echo $__env->make('client.components.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- / catg header banner section -->

 <!-- Cart view section -->
 <section id="aa-myaccount">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
        <div class="aa-myaccount-area">
            <div class="row">
              <div class="col-md-12">
                <?php echo $__env->make('client.components.massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('client.components.errorMassage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="aa-myaccount-register">
                 <h4>Register</h4>
                 <form action="<?php echo e(route('client.addUser')); ?>" class="aa-login-form registration" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="">Full Name<span>*</span></label>
                    <input required name="name" type="text" placeholder="Name" value="<?php echo e(old('name')); ?>">
                    <label for="phone">Phone Number<span>*</span></label>
                    <input required name="phone_number" type="number" placeholder="Phone Number" value="<?php echo e(old('phone_number')); ?>">
                    <label for="">Email address<span>*</span></label>
                    <input required name="email" type="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <label for="">Password<span>*</span></label>
                    <input required name="password" type="password" placeholder="Password">
                    <label for="">Confirm Password<span>*</span></label>
                    <input required name="password_confirmation" type="password" placeholder="Confirm Password">
                    <button type="submit" class="aa-browse-btn">Register</button>
                  </form>
                </div>
              </div>
            </div>
            <div class="row">
                <?php if(auth()->guard()->guest()): ?>
                    <div class="col-md-12"  style="margin-top: 20px !important">
                        <p>Have Account? Please <a class="text-primary" href="<?php echo e(route('client.login')); ?>"> Login </a> Now</p>
                    </div>
                <?php endif; ?>
            </div>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- / Cart view section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asulsisc/public_html/resources/views/client/pages/registration.blade.php ENDPATH**/ ?>