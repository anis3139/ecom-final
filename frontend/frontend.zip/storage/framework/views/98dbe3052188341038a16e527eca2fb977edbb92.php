<style>
 .aa-product-catg li figure .aa-add-card-btn {
    width: 100%;
}

</style>

<section id="aa-popular-category">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="aa-popular-category-area">
                        <!-- start prduct navigation -->
                        <ul class="nav nav-tabs aa-products-tab">
                            <li class="active"><a href="#popular" data-toggle="tab">Popular</a></li>
                            <li><a href="#featured" data-toggle="tab">Featured</a></li>
                            <li><a href="#latest" data-toggle="tab">Latest</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <!-- Start men popular category -->
                            <div class="tab-pane fade in active" id="popular">
                                <ul class="aa-product-catg aa-popular-slider">
                                    <!-- start single product item -->

                                    <?php $__currentLoopData = $popular_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <figure>
                                                <?php $i= 1; ?>
                                                <?php $__currentLoopData = $popular_product->product->img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              
                                                    <?php if($i > 0): ?>
                                                        <a class="aa-product-img"
                                                            href="<?php echo e(route('client.showProductDetails', ['slug' => $popular_product->product->product_slug])); ?>"><img
                                                                src="<?php echo e($images['image_path']); ?>" alt="polo shirt img"
                                                                width="100%" height="300px"></a>
                                                    <?php endif; ?>
                                                    <?php $i--; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <a  class="aa-add-card-btn"  onclick="productDetailsModal(<?php echo e($popular_product->product_id); ?>)"
                                                    href="" data-toggle2="tooltip" data-placement="top"
                                                   data-toggle="modal" data-target="#quick-view-modal"><span
                                                                class="fa fa-shopping-cart" id="CartAddConfirmBtn"></span>Add To
                                                            Cart</a>

                                                <figcaption>
                                                    <h4 class="aa-product-title"><a
                                                            href="<?php echo e(route('client.showProductDetails', ['slug' => $popular_product->product->product_slug])); ?>"><?php echo e($popular_product->product->product_title); ?></a>
                                                    </h4>
                                                    <span
                                                        class="aa-product-price">&euro; &nbsp;<?php echo e($popular_product->product->product_selling_price); ?></span><span
                                                        class="aa-product-price"><del>&euro; &nbsp;<?php echo e($popular_product->product->product_price); ?></del></span>
                                                </figcaption>
                                            </figure>
                                            <div class="aa-product-hvr-content">
                                                
                                                    <a onclick="productDetailsModal(<?php echo e($popular_product->product_id); ?>)"
                                                        data-toggle2="tooltip" data-placement="top"
                                                        title="Quick View" data-toggle="modal" data-target="#quick-view-modal"><span
                                                            class="fa fa-search"></span>
                                                    </a>
                                            </div>
                                            <!-- product badge -->
                                            <?php if($popular_product->product->product_in_stock): ?>
                                                <span class="aa-badge aa-sale" href="#">
                                                    SALE!
                                                </span>
                                            <?php else: ?>
                                                <span class="aa-badge aa-sold-out" href="#">Sold Out!</span>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- end single product item -->

                                </ul>
                                <a class="aa-browse-btn" href="<?php echo e(route('client.shop')); ?>">Browse all Product <span
                                        class="fa fa-long-arrow-right"></span></a>
                            </div>
                            <!-- / popular product category -->

                            <!-- start featured product category -->
                            <div class="tab-pane fade" id="featured">
                                <ul class="aa-product-catg aa-featured-slider">
                                    <!-- start single product item -->
                                    <?php $__currentLoopData = $featureProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featureProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <figure>
                                                <?php $i= 1; ?>
                                                <?php $__currentLoopData = $featureProduct->img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i > 0): ?>
                                                        <a class="aa-product-img"
                                                            href="<?php echo e(route('client.showProductDetails', ['slug' => $featureProduct->product_slug])); ?>"><img
                                                                src="<?php echo e($images->image_path); ?>" alt="polo shirt img"
                                                                width="100%" height="300px"></a>
                                                    <?php endif; ?>
                                                    <?php $i--; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <a  class="aa-add-card-btn"  onclick="productDetailsModal(<?php echo e($featureProduct->id); ?>)"
                                                    href="" data-toggle2="tooltip" data-placement="top"
                                                   data-toggle="modal" data-target="#quick-view-modal"><span
                                                                class="fa fa-shopping-cart" id="CartAddConfirmBtn"></span>Add To
                                                            Cart</a>
                                                <figcaption>
                                                    <h4 class="aa-product-title"><a
                                                            href="<?php echo e($featureProduct->product_slug); ?>"><?php echo e($featureProduct->product_title); ?></a>
                                                    </h4>
                                                    <span
                                                        class="aa-product-price"><?php echo e($featureProduct->product_selling_price); ?></span><span
                                                        class="aa-product-price"><del><?php echo e($featureProduct->product_price); ?></del></span>
                                                </figcaption>
                                            </figure>
                                            <div class="aa-product-hvr-content">
                                                
                                                    <a onclick="productDetailsModal(<?php echo e($featureProduct->id); ?>)"
                                                        data-toggle2="tooltip" data-placement="top"
                                                        title="Quick View" data-toggle="modal" data-target="#quick-view-modal"><span
                                                            class="fa fa-search"></span></a>
                                            </div>
                                            <!-- product badge -->
                                            <?php if($featureProduct->product_in_stock): ?>
                                                <span class="aa-badge aa-sale" href="#">
                                                    SALE!
                                                </span>
                                            <?php else: ?>
                                                <span class="aa-badge aa-sold-out" href="<?php echo e(route('client.shop')); ?>">Sold Out!</span>
                                            <?php endif; ?>
                                        </li>
                                        <!-- start single product item -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <a class="aa-browse-btn" href="#">Browse all Product <span
                                        class="fa fa-long-arrow-right"></span></a>
                            </div>
                            <!-- / featured product category -->

                            <!-- start latest product category -->
                            <div class="tab-pane fade" id="latest">
                                <ul class="aa-product-catg aa-latest-slider">
                                    <!-- start single product item -->
                                    <?php $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <li>
                                            <figure>
                                                <?php $i= 1; ?>
                                                <?php $__currentLoopData = $latestProduct->img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i > 0): ?>
                                                        <a class="aa-product-img"
                                                            href="<?php echo e(route('client.showProductDetails', ['slug' => $latestProduct->product_slug])); ?>"><img
                                                                src="<?php echo e($images->image_path); ?>" alt="polo shirt img"
                                                                width="100%" height="300px"></a>
                                                    <?php endif; ?>
                                                    <?php $i--; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <a  class="aa-add-card-btn"  onclick="productDetailsModal(<?php echo e($latestProduct->id); ?>)"
                                                    href="" data-toggle2="tooltip" data-placement="top"
                                                   data-toggle="modal" data-target="#quick-view-modal"><span
                                                                class="fa fa-shopping-cart" id="CartAddConfirmBtn"></span>Add To
                                                            Cart</a>
                                                <figcaption>
                                                    <h4 class="aa-product-title"><a href="<?php echo e(route('client.showProductDetails', ['slug' => $latestProduct->product_slug])); ?>"><?php echo e($latestProduct->product_title); ?></a></h4>
                                                    <span class="aa-product-price">&euro; &nbsp;<?php echo e($latestProduct->product_selling_price); ?></span><span
                                                        class="aa-product-price"><del>&euro; &nbsp;<?php echo e($latestProduct->product_price); ?></del></span>
                                                </figcaption>
                                            </figure>
                                            <div class="aa-product-hvr-content">
                                                
                                                    <a onclick="productDetailsModal(<?php echo e($latestProduct->id); ?>)"
                                                        data-toggle2="tooltip" data-placement="top"
                                                        title="Quick View" data-toggle="modal" data-target="#quick-view-modal"><span
                                                            class="fa fa-search"></span></a>
                                            </div>
                                            <!-- product badge -->
                                            <?php if($latestProduct->product_in_stock): ?>
                                                <span class="aa-badge aa-sale" href="#">
                                                    SALE!
                                                </span>
                                            <?php else: ?>
                                                <span class="aa-badge aa-sold-out" href="#">Sold Out!</span>
                                            <?php endif; ?>
                                        </li>
                                        <!-- end single product item -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <a class="aa-browse-btn" href="<?php echo e(route('client.shop')); ?>">Browse all Product <span
                                        class="fa fa-long-arrow-right"></span></a>
                            </div>
                            <!-- / latest product category -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/asulsisc/public_html/resources/views/client/partials/popularProducts.blade.php ENDPATH**/ ?>