
  <!-- Subscribe section -->
  <!--<section id="aa-subscribe">-->
  <!--  <div class="container">-->
  <!--    <div class="row">-->
  <!--      <div class="col-md-12">-->
  <!--        <div class="aa-subscribe-area">-->
  <!--          <h3>Subscribe our newsletter </h3>-->
  <!--          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, velit!</p>-->
  <!--          <form action="" class="aa-subscribe-form">-->
  <!--            <input type="email" name="" id="" placeholder="Enter your Email">-->
  <!--            <input type="submit" value="Subscribe">-->
  <!--          </form>-->
  <!--        </div>-->
  <!--      </div>-->
  <!--    </div>-->
  <!--  </div>-->
  <!--</section>-->
  <!-- / Subscribe section -->

  <?php /**PATH C:\Users\Abedin\Documents\GitHub\ecom-final\frontend\resources\views/client/components/newslatter.blade.php ENDPATH**/ ?>