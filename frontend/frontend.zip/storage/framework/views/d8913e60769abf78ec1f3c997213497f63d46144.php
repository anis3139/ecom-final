<section id="aa-client-brand">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-client-brand-area">
            <ul class="aa-client-brand-slider">
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-java.png" alt="java img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-jquery.png" alt="jquery img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-html5.png" alt="html5 img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-css3.png" alt="css3 img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-wordpress.png" alt="wordPress img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-joomla.png" alt="joomla img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-java.png" alt="java img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-jquery.png" alt="jquery img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-html5.png" alt="html5 img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-css3.png" alt="css3 img"></a></li>
              <li><a href="#"><img src="<?php echo e(asset('client/img')); ?>/client-brand-wordpress.png" alt="wordPress img"></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section> <?php /**PATH C:\Users\Abedin\Documents\GitHub\ecom-final\frontend\resources\views/client/components/client.blade.php ENDPATH**/ ?>