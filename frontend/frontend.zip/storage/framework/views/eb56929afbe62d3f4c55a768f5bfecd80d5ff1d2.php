<!-- menu -->
<section id="menu" style="position: sticky !important; top:0px !important; z-index:999;">
    <div class="container">
        <div class="menu-area">
            <!-- Navbar -->
            <div class="navbar navbar-default" role="navigation">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <!-- Left nav -->
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(route('client.home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('client.shop')); ?>">Shop</a></li>

                        <?php $__currentLoopData = App\Models\ProductsCategoryModel::orderby('name', 'asc')  ->where('parent_id', 0)  ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('client.category',  $parentCat->slug)); ?> "><?php echo e($parentCat->name); ?> <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                 <?php $__currentLoopData = App\Models\ProductsCategoryModel::orderby('name', 'asc') ->where('parent_id', $parentCat->id)  ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('client.category', $childCat->slug)); ?>"><?php echo e($childCat->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('client.about')); ?>">About us</a></li>
  <li><a href="<?php echo e(route('client.contact')); ?>">Contact</a></li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </div>
    </div>
</section>
<!-- / menu -->
<?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/components/menu.blade.php ENDPATH**/ ?>