<?php $__env->startSection('css'); ?>

<style>
.profile{
    margin: 20px 0px!important;
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <img  src="<?php echo e(auth()->user()->image ?? asset('/default-image.png')); ?>" alt="<?php echo e(auth()->user()->name); ?>" width="150px" height="150px" style="border-radius:50%; margin:20px  auto !important; display:block;">
                <table class="table table-borderless table-hover" style="padding:10px;">
                    <tr>
                        <td>name:</td>
                        <td><?php echo e(auth()->user()->name); ?></td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td><?php echo e(auth()->user()->email); ?></td>
                    </tr>
                    <tr>
                        <td>Mobile:</td>
                        <td><?php echo e(auth()->user()->phone_number); ?></td>
                    </tr>
                    <tr>
                        <td>Adress:</td>
                        <td><?php echo e(auth()->user()->address); ?></td>
                    </tr>
                    <tr>
                        <td>City:</td>
                        <td><?php echo e(auth()->user()->city); ?></td>
                    </tr>
                    <tr>
                        <td>District:</td>
                        <td><?php echo e(auth()->user()->district); ?></td>
                    </tr>
                    <tr>
                        <td>Zip code:</td>
                        <td><?php echo e(auth()->user()->postal_code); ?></td>
                    </tr>
                    <tr>

                        <td colspan="2"><a class="btn btn-success" href="<?php echo e(route('client.profileEdit', auth()->user()->id)); ?>" style="margin:20px  auto !important; display:block;"><h4>Profile Edit</h4></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-12 text-center">

                <table class="table table-bordered table-hover" style="padding:10px; margin-top:20px;">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer name</th>
                            <th class="hidden-xs">Customer Phone Number</th>
                            <th>Total Amount</th>
                            <th>Paid Amount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->customer_name); ?></td>
                                <td class="hidden-xs"><?php echo e($order->customer_phone_number); ?></td>
                                <td>&euro;&nbsp;<?php echo e(number_format($order->total_amount, 2)); ?></td>
                                <td>&euro;&nbsp;<?php echo e(number_format($order->paid_amount, 2)); ?></td>
                                <td><a class="text-primary" href="<?php echo e(route('client.orderDetails', $order->id)); ?>">View Details</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/pages/profile.blade.php ENDPATH**/ ?>