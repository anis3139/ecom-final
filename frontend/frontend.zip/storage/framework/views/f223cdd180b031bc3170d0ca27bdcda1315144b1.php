<?php $__env->startSection('content'); ?>


 <!-- catg header banner section -->
 <?php echo $__env->make('client.components.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- / catg header banner section -->


<div id="login" class="container">

    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 ml-auto">
        <div class="login-card card">
            <div class="card-header border-0 ">
                <h2 class="text-center" style="margin-top: 20px">Profile Update</h2>
            </div>
            <div class="card-body pt-0">
                <?php echo $__env->make('client.components.massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('client.components.errorMassage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <form action="<?php echo e(route('client.upadeteProfile', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <img id="profileImage" style="height: 150px !important; width: 150px !important; height:150px; border-radius:50%; margin:20px auto; display:block;"
                        class="imgPreview mx-auto d-block" src="<?php echo e($user->image ?? asset('/default-image.png')); ?>" />
                    <div class="form-group my-4">

                        <input type="file" class="form-control login" name="image" id="image" >
                    </div>
                    <div class="form-group my-4">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control login" name="name"  placeholder="Name" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="form-group my-4">
                        <label for="Phone">Mobile:</label>
                        <input type="text" class="form-control login"name="phone_number" placeholder="Phone Number" value="<?php echo e($user->phone_number); ?>">
                    </div>
                    <div class="form-group my-4">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control login" name="email" id="email" placeholder="Email"  value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="form-group my-4">
                            <label for="address">Address:</label>
                        <textarea cols="30" rows="10"  class="form-control login" name="address" id="address" placeholder="Address" ><?php echo e($user->address); ?></textarea>
                    </div>
                    <div class="form-group my-4">
                        <label for="city">City:</label>
                        <input type="text" class="form-control login" name="city" id="city" placeholder="City"  value="<?php echo e($user->city); ?>">
                    </div>
                    <div class="form-group my-4">
                        <label for="district">District: </label>
                        <input type="text" class="form-control login" name="district" id="district" placeholder="District"  value="<?php echo e($user->district); ?>">
                    </div>
                    <div class="form-group my-4">
                        <label for="postal_code">Zip Code: </label>
                        <input type="text" class="form-control login" name="postal_code" id="postal_code" placeholder="Zip Code"  value="<?php echo e($user->postal_code); ?>">
                    </div>


                    <div class="form-group text-center my-4">
                        <input type="submit" class="btn btn-success btn-disable btn-block p-2 font-weight-bold" value="Update" >
                    </div>
                </form>




            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
 <?php $__env->startSection('script'); ?>

    <script>
          $('#image').change(function() {
            var reader = new FileReader();
            reader.readAsDataURL(this.files[0]);
            reader.onload = function(event) {
                var ImgSource = event.target.result;
                $('#profileImage').attr('src', ImgSource)
            }
        })
    </script>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asulsisc/public_html/resources/views/client/pages/profileEdit.blade.php ENDPATH**/ ?>