<?php $__env->startSection('css'); ?>
<style>
    @media  only screen and (max-width: 600px) {
  #cartTable {
        overflow:auto;
        display:block;
        min-width:300px;
  }
  .cart-view-total a{
      display: block;
      margin: 20px;
      padding: 10px;
      font-size: 15px;
      float: none;

  }


}
</style>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- catg header banner section -->
  <?php echo $__env->make('client.components.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- / catg header banner section -->


    <!-- Cart view section -->
    <section id="cart-view" style="margin:0px 0px 20px 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <div class="cart-view-area">
                        <div class="cart-view-table">
                            <?php echo $__env->make('client.components.massege', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                            <?php if(empty($cart)): ?>
                                <div class="table-responsive">
                                    <div class="alert alert-info alert-block">
                                        <p>Please Add Some Product On Your Cart. <a class="text-primary" href="<?php echo e(route('client.shop')); ?>"> Go Shop Page</a></p>
                                    </div>
                                <?php else: ?>
                                    <table class="table table-bordered" id="cartTable">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>Image</th>
                                                <th>Product</th>
                                                <th>Unit Price</th>
                                                <th>Quantity</th>
                                                <th>Color</th>
                                                <th>Meserment</th>
                                                <th>Total Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td style="width: 50px">
                                                        <form action="<?php echo e(route('client.cartRemove')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" value="<?php echo e($key); ?>" name="product_id">
                                                            <button type="submit" class="btn btn-warning">
                                                                Remove
                                                            </button>
                                                        </form>
                                                    </td>

                                                    <td><img src="<?php echo e($cartItem['image']); ?>" alt=""></td>


                                                    <td><a class="aa-cart-title" href="#"><?php echo e($cartItem['title']); ?></a></td>

                                                    <td>&euro; &nbsp;<?php echo e(number_format($cartItem['unit_price']), 2); ?> </td>

                                                    <td><?php echo e($cartItem['quantity']); ?></td>
                                                    <td style="display:flex; justify-content:center; align-items: center; height:20vh;">
                                                        <?php if( $cartItem['maserment']): ?>

                                                        <div style=" width:20px; height:20px; border:1px solid #000; border-radius:50%; background-color: <?php echo e($cartItem['color']); ?>;"></div>
                                                        <?php else: ?>
                                                        <?php echo e("N/A"); ?>

                                                    <?php endif; ?>
                                                    </td>
                                                    <td><?php if( $cartItem['maserment']): ?>
                                                        <?php echo e($cartItem['maserment']); ?>

                                                        <?php else: ?>
                                                        <?php echo e("N/A"); ?>

                                                    <?php endif; ?></td>

                                                    <td>&euro; &nbsp;<?php echo e(number_format($cartItem['total_price'], 2)); ?>

                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td style="font-weight: bold; text-align:center;">
                                                    <a href="<?php echo e(route('client.ClearCart')); ?>" class="btn btn-danger">Clear All Cart</a>
                                                </td>
                                                <td colspan="6" style="font-weight: bold; text-align:center;">
                                                    Total
                                                </td>
                                                <td style="font-weight: bold; text-align:center;">
                                                    &euro; &nbsp;<?php echo e(number_format($total, 2)); ?>

                                                </td>

                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>




                                    <!-- Cart Total view -->
                                    <div class="cart-view-total">
                                        <a href="<?php echo e(route('client.checkout')); ?>" class="aa-cart-view-btn">Proced to Checkout</a>
                                    </div>


                                <!-- Cart Clear -->



                            <?php endif; ?>


                                    <!-- Cart Total -->
                                    <div class="cart-view-total" style="margin:0px auto; display:block; width:auto; float:left;">
                                        <a href="<?php echo e(route('client.shop')); ?>" class="aa-cart-view-btn" style="background-color:#FF6666 !important;">Continue Shoping</a>
                                    </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- / Cart view section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/pages/cart.blade.php ENDPATH**/ ?>