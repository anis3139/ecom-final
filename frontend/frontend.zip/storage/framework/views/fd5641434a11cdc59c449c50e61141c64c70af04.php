<?php
$others=App\Models\OthersModel::first();
?>
<!-- Start header section -->
<header id="aa-header">
    <!-- start header top  -->
    <div class="aa-header-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="aa-header-top-area">
                        <!-- start header top left -->
                        <div class="aa-header-top-left">
                            <!-- start language -->
                            <div class="aa-language">
                                <div class="dropdown">

                                    <p className="mt-1" id="google_translate_element"></p>
                                </div>
                            </div>
                            <!-- / language -->

                            <!-- start currency -->
                            <div class="aa-currency">
                                <div class="dropdown">
                                    <a class="btn dropdown-toggle" href="#" type="button" id="dropdownMenu1"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        <i class="fa fa-euro"></i>EURO
                                        <span class="caret"></span>
                                    </a>
                                    <!--<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">-->
                                    <!--    <li><a href="#"><i class="fa fa-euro"></i>EURO</a></li>-->
                                    <!--    <li><a href="#"><i class="fa fa-jpy"></i>YEN</a></li>-->
                                    <!--</ul>-->
                                </div>
                            </div>
                            <!-- / currency -->
                            <!-- start cellphone -->
                            <div class="cellphone hidden-xs">
                                <p><span class="fa fa-phone"></span>  <a href="tel:<?php if($others): ?>
                                   <?php echo e($others->phone); ?>

                                   <?php endif; ?>">
                                   <?php if($others): ?>
                                   <?php echo e($others->phone); ?>

                                   <?php endif; ?></a></p>
                            </div>
                            <!-- / cellphone -->
                        </div>
                        <!-- / header top left -->
                        <div class="aa-header-top-right">
                            <ul class="aa-head-top-nav-right">
                                <!--<li class="hidden-xs"><a href="#">Wishlist</a></li>-->
                                <li class="hidden-xs"><a href="<?php echo e(route('client.showCart')); ?>">My Cart</a></li>
                                <li class="hidden-xs"><a href="<?php echo e(route('client.checkout')); ?>">Checkout</a></li>
                                <?php if(auth()->guard()->check()): ?>
                                <li><a href="<?php echo e(route('client.profile')); ?>">My Account</a></li>
                                <li><a href="<?php echo e(route('client.logout')); ?>">Log Out</a></li>
                                <?php endif; ?>
                                <?php if(auth()->guard()->guest()): ?>
                                <li><a href="" data-toggle="modal" data-target="#login-modal">Login</a></li>
                                <li><a href="<?php echo e(route('client.registration')); ?>" >Registration</a></li>
                                <?php endif; ?>
                                    <?php
                                        $host = $_SERVER['HTTP_HOST'];
                                        $protocol = $_SERVER['PROTOCOL'] = isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) ? 'https://' : 'http://';
                                        $location =$protocol ."vendor.". $host;

                                    ?>
                                <li class="hidden-xs"><a href="<?php echo e($location); ?>">Seller Point</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / header top  -->

    <!-- start header bottom  -->
    <div class="aa-header-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="aa-header-bottom-area">
                        <!-- logo  -->
                        <div class="aa-logo">
                           <?php if($others): ?>
                            <a href="<?php echo e(route('client.home')); ?>"><img src="<?php if($others): ?>
                                <?php echo e($others->logo); ?>

                                <?php endif; ?>" alt="logo img" width="100px" height="60px"></a>
                            <?php else: ?>
                             <!-- Text based logo -->
                             <a href="<?php echo e(route('client.home')); ?>">
                                <span class="fa fa-shopping-cart"></span>
                                <p>Rainy<strong>Forest</strong> <span>Your Shopping Partner</span></p>
                            </a>
                            <!-- img based logo -->
                            <?php endif; ?>
                        </div>
                        <!-- / logo  -->
                        <!-- cart box -->
                        <div class="aa-cartbox">
                            <a class="aa-cart-link" href="#">
                                <span class="fa fa-shopping-basket"></span>
                                <span class="aa-cart-title">SHOPPING CART</span>
                                <!--<span class="aa-cart-notify">2</span>-->
                            </a>
                            <div class="aa-cartbox-summary">
                                <!--<ul>-->
                                <!--    <li>-->
                                <!--        <a class="aa-cartbox-img" href="#"><img-->
                                <!--                src="<?php echo e(asset('client/img')); ?>/woman-small-2.jpg" alt="img"></a>-->
                                <!--        <div class="aa-cartbox-info">-->
                                <!--            <h4><a href="#">Product Name</a></h4>-->
                                <!--            <p>1 x $250</p>-->
                                <!--        </div>-->
                                <!--        <a class="aa-remove-product" href="#"><span class="fa fa-times"></span></a>-->
                                <!--    </li>-->
                                <!--    <li>-->
                                <!--        <a class="aa-cartbox-img" href="#"><img-->
                                <!--                src="<?php echo e(asset('client/img')); ?>/woman-small-1.jpg" alt="img"></a>-->
                                <!--        <div class="aa-cartbox-info">-->
                                <!--            <h4><a href="#">Product Name</a></h4>-->
                                <!--            <p>1 x $250</p>-->
                                <!--        </div>-->
                                <!--        <a class="aa-remove-product" href="#"><span class="fa fa-times"></span></a>-->
                                <!--    </li>-->
                                <!--    <li>-->
                                <!--        <span class="aa-cartbox-total-title">-->
                                <!--            Total-->
                                <!--        </span>-->
                                <!--        <span class="aa-cartbox-total-price">-->
                                <!--            $500-->
                                <!--        </span>-->
                                <!--    </li>-->
                                <!--</ul>-->
                                <a class="aa-cartbox-checkout aa-primary-btn"
                                    href="<?php echo e(route('client.checkout')); ?>">Checkout</a>
                            </div>
                        </div>
                        <!-- / cart box -->
                        <!-- search box -->
                        <div class="aa-search-box">
                            <form action="<?php echo e(route('client.search')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="key" id="key" placeholder="Search Product">
                                <button type="submit"><span class="fa fa-search"></span></button>
                            </form>
                        </div>
                        <!-- / search box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / header bottom  -->
</header>
<!-- / header section -->
<?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/components/header.blade.php ENDPATH**/ ?>