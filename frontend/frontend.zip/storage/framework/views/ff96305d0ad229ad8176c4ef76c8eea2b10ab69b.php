
  <!-- Start slider -->
  <section id="aa-slider">
    <div class="aa-slider-area" >
      <div id="sequence" class="seq"  style="width: 100%; max-height:400px;">
        <div class="seq-screen">
          <ul class="seq-canvas">
            <!-- single slide item -->
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li>
              <div class="seq-model">
                <img data-seq src="<?php echo e($slider->image); ?>" alt="Men slide img"/>
              </div>
              <div class="seq-title">

                <h2 data-seq><?php echo e($slider->title); ?></h2>
                <p data-seq><?php echo e($slider->sub_title); ?></p>
                <a data-seq href="<?php echo e(route('client.shop')); ?>" class="aa-shop-now-btn aa-secondary-btn">SHOP NOW</a>
              </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- single slide item -->


          </ul>
        </div>
        <!-- slider navigation btn -->
        <fieldset class="seq-nav" aria-controls="sequence" aria-label="Slider buttons">
          <a type="button" class="seq-prev" aria-label="Previous"><span class="fa fa-angle-left"></span></a>
          <a type="button" class="seq-next" aria-label="Next"><span class="fa fa-angle-right"></span></a>
        </fieldset>
      </div>
    </div>
  </section>
  <!-- / slider -->
<?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-final\frontend\resources\views/client/partials/slider.blade.php ENDPATH**/ ?>