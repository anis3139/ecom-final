<div class="main-div">
<section class="about-section">
    <div class="container">
        <div class="containt">
            <div class="row">
  
                <div class="col-md-5">
                    <div class="left-contain">
                        <img src="{{asset('client/img')}}/Fashion1.jpg" alt="">
                    </div>
                </div>
  
            <div class="col-md-7 ">
                <div class="right-contain">
                    <div class="right-header">
                        <h1>about us</h1>
                    </div>
                    <div class="right-details">
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rerum facere distinctio
                        saepe magnam repudiandae. Dolor quis provident nulla repellendus praesentium aut
                        enim quisquam odit nam, asperiores quo inventore mollitia saepe ad fugit. Rerum magnam
                        consectetur accusantium nesciunt unde! Quidem porro temporibus,
                        illum nostrum voluptatem dolore veniam ipsam provident vel rem?</p>
                    </div>
                </div>
            </div>
        </div>
  
    </div>
  </section>