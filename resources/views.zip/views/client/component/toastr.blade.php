@if (Session::has('success'))
    <script>
        toastr.success("{{ Session::get('success') }}", {
            closeButton: true,
            progressBar: true,
        })

    </script>
@endif
@if (Session::has('error'))
    <script>
        toastr.error("{{ Session::get('error') }}", {
            closeButton: true,
            progressBar: true,
        })

    </script>
@endif
@if (Session::has('warning'))
    <script>
        toastr.warning("{{ Session::get('warning') }}", {
            closeButton: true,
            progressBar: true,
        })

    </script>
@endif
@if (Session::has('info'))
    <script>
        toastr.info("{{ Session::get('info') }}", {
            closeButton: true,
            progressBar: true,
        })

    </script>
@endif
