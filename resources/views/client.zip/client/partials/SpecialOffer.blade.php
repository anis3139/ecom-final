<div class="section footer-stick bg-white m-0 py-3 border-bottom">
                    <div class="container clearfix">

                        <div class="row clearfix">
                            <div class="col-lg-4 col-md-6">
                                <div class="shop-footer-features mb-3 mb-lg-3"><i class="icon-line2-wallet text-dark"></i>
                                    <h5 class="inline-block mb-0 ml-2 font-weight-semibold"><a href="#">Easy </a><span class="font-weight-normal text-muted"> &amp; </span>Secured Payment</h5>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="shop-footer-features mb-3 mb-lg-3"><i class="icon-line2-notebook"></i>
                                    <h5 class="inline-block mb-0 ml-2"><a href="#">Geniune Products</a><span
                                            class="font-weight-normal text-muted"> Guaranteed</span></h5>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div class="shop-footer-features mb-3 mb-lg-3"><i class="icon-line2-reload text-dark"></i>
                                    <h5 class="inline-block mb-0 ml-2"><a href="#">7 Days </a> <span
                                            class="font-weight-normal text-muted">Return Policy</span></h5>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>